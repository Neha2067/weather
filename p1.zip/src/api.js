export const geoApiOptions = {
    method: 'GET',
    headers: {
        'X-RapidAPI-Key': '0c7ee2fa3dmsh4cf6fd18e1f7fa5p19c470jsn821ba0cf9b77',
        'X-RapidAPI-Host': 'wft-geo-db.p.rapidapi.com'
    }
};

export const GEO_API_URL = "https://wft-geo-db.p.rapidapi.com/v1/geo";

export const WEATHER_API_URL = "https://api.openweathermap.org/data/2.5/";

export const WEATHER_API_KEY = "10853c1a09332262952218672c6c939b";